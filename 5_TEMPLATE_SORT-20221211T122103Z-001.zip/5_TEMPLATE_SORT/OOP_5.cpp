#include<iostream>
using namespace std;
template<class T>
class sort
{
	T a[50];
	int n;
public:
	void accept()
	{
		cout<<"\n Enter no. of elements in an array : ";
		cin>>n;
		cout<<"\n Enter elements : ";
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
	}
	void selection_sort()
	{
		T temp;
		for(int i=0;i<n-1;i++)
		{
			int min=i;
			for(int j=i+1;j<n;j++)
			{
				if(a[min]>a[j])
				{
					min=j;
				}
			}
			temp=a[min];
			a[min]=a[i];
			a[i]=temp;
		}
	}
	void display()
	{
		cout<<"Sorted Array"<<endl;
		for(int i=0;i<n;i++)
		{
			cout<<a[i]<<"	";
		}
	}
};
int main()
{
	sort <int> s1;
	sort <float> s2;
	int choice;
	do
	{
		cout<<endl<<"-------------------MENU-------------------";
		cout<<"\n 1. Integer : ";
		cout<<"\n 2. Float : ";
		cout<<"\n 3. Exit :";
		cout<<"\n Enter Choice : ";
		cin>>choice;
		switch(choice)
		{
			case 1:
				s1.accept();
				s1.selection_sort();
				s1.display();
				break;
			case 2:
				s2.accept();
				s2.selection_sort();
				s2.display();
				break;
			case 3:
				cout<<"Exited";
				exit(0);
		}
	}
	while(choice!=4);
	return 0;
}
